
//we will create 2 transactions\n//FROM ACCOUNT, AMOUNT and TO ACCOUNT and AMOUNT
//add account type to each and mange parent to determine which account\n\n
var fromBean = true ? 'CHECKING_TRANS' : 'SAVINGS_TRANS';
var toBean = false ? 'CHECKING_TRANS' : 'SAVINGS_TRANS';
var fromAccount = logicContext.createPersistentBean(fromBean);
fromAccount.CustNum = row.FromCustNum;
fromAccount.AcctNum = row.FromAcct;
fromAccount.WithdrawlAmt = row.TransferAmt;
fromAccount.DepositAmt = 0;
fromAccount.PendingFlag = 0;
if(fromBean === 'CHECKING_TRANS' ){
    fromAccount.ChkNo = 'TRF: '+row.ToAcct;
}
logicContext.insert(fromAccount);
var toAccount = logicContext.createPersistentBean(toBean);
toAccount.CustNum = row.ToCustNum;
toAccount.AcctNum = row.ToAcct;
toAccount.DepositAmt = row.TransferAmt;
toAccount.PendingFlag = 0;
toAccount.WithdrawlAmt = 0;
logicContext.insert(toAccount);
return true;
