return row.fk_Alert_CUSTOMER1.TotalBalance >row.WhenBalance;
