if (oldRow.AlertID != row.AlertID) {
    log.debug("Sample Event Rule for ALERT table:  AlertID column updated to " + row.AlertID);
}
else {
    log.debug("Sample Event Rule for ALERT table: AlertID column unchanged.");
}
