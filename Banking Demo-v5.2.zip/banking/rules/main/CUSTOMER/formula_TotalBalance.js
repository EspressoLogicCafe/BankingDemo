return row.CheckingAcctBal+row.SavingsAcctBal
