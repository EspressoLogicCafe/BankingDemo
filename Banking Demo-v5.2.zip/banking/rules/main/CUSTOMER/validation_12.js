return row.CheckingAcctBal >= 0;
