return row.Deposits - row.Withdrawls;
