# API
This folder contains the content of your API definition.
Name: Banking Demo
URL Fragment: banking
Comments: 1. Deploy your SQL to a database
2. Change your Data Source database connections
3. Change the Authentication Provider (above)
4.. Data Explorer - select Transfer Funds
